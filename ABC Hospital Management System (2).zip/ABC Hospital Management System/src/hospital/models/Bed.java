/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hospital.models;

/**
 *
 * @author ERONMWON
 */
public class Bed {
    private int id;
    private int AdmissionId;
    private String bedNumber ; 
    private Room room; 
    private boolean occupied;
    
    public Bed(){
    
    }
    
    

    public int getId() {
        return id;
    }

    public int getAdmissionId() {
        return AdmissionId;
    }

    public void setAdmissionId(int AdmissionId) {
        this.AdmissionId = AdmissionId;
    }

    
    public String getBedNumber() {
        return bedNumber;
    }

    public void setBedNumber(String bedNumber) {
        this.bedNumber = bedNumber;
    }

    public Room getRoom() {
        return room;
    }

    public void setRoom(Room room) {
        this.room = room;
    }

    public boolean isOccupied() {
        return occupied;
    }

    public void setOccupied(boolean occupied) {
        this.occupied = occupied;
    }
    
    
    
}
